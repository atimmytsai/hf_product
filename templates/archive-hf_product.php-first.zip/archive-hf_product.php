<?php get_header(); ?>

<div class="container">

    <h1><?php post_type_archive_title(); ?></h1>

    <form method="get" action="<?php echo esc_url(get_post_type_archive_link('hf_product')); ?>">

        <!-- other form inputs here -->

        <?php

        $taxonomies = ['voltage', 'material', 'category', 'flange'];

        foreach ($taxonomies as $taxonomy) {

            $terms = get_terms([

                'taxonomy' => $taxonomy,

                'hide_empty' => true,

            ]);

            if (!empty($terms)) {

                echo '<select name="' . $taxonomy . '">';

                echo '<option value="">All ' . ucfirst($taxonomy) . 's</option>';

                foreach ($terms as $term) {

                    printf('<option value="%s">%s</option>', $term->slug, $term->name);

                }

                echo '</select>';

            }

        }

        ?>

        <button type="submit">Filter</button>

    </form>





    <?php

    $args = [

        'post_type' => 'hf_product',

        'posts_per_page' => -1,

        'tax_query' => [],

    ];

    foreach ($taxonomies as $taxonomy) {

        if (!empty($_GET[$taxonomy])) {

            $args['tax_query'][] = [

                'taxonomy' => $taxonomy,

                'field' => 'slug',

                'terms' => $_GET[$taxonomy],

            ];

        }

    }

    $query = new WP_Query($args);

    if ($query->have_posts()): ?>

        <div class="hf-products">

            <?php while ($query->have_posts()): $query->the_post(); ?>

                <div class="hf-product">

                    <h2><?php the_title(); ?></h2>

                    <?php the_excerpt(); ?>

                    <a href="<?php the_permalink(); ?>">Read more</a>

                </div>

            <?php endwhile; ?>

        </div>

    <?php endif;

    wp_reset_postdata(); ?>

</div>

<?php get_footer(); ?>